import numpy as np
import traceback
import pyvista
from dolfinx.io import XDMFFile
from dolfinx.io import gmsh as gmshio
import gmsh 
from petsc4py import PETSc
from mpi4py import MPI
from ufl import *
from dolfinx.fem import *
from dolfinx.fem.petsc import *
from dolfinx.mesh import *
from dolfinx import default_scalar_type, plot, default_real_type
from dolfinx.fem.petsc import (
    create_matrix, assemble_matrix, apply_lifting, 
    assemble_vector, set_bc, LinearProblem, create_vector
)
from basix.ufl import element, mixed_element

file_name = "cbox_st" 
linesearch = 'bt'
mesh_order = 1
target_displacement = -1.0
p_space = "CG"

# Nonlinear solver parameters
atol_newton = 1e-18; rtol_newton = 1e-17; stol_newton = 1e-20; max_it_newton = 10

# Staggered iteration parameters
max_it_staggered = 100; err_tol_staggered = 1e-3

# Adaptive load stepping parameters
Nsteps = 100; Nsteps_min = 40; Nsteps_max = 800
crit_displacement = -0.8
initial_step_size = abs(target_displacement)/Nsteps
min_step_size = abs(target_displacement)/Nsteps_max
max_step_size = abs(target_displacement)/Nsteps_min 
increase_factor = 1.5; decrease_factor = 0.5
max_attempts = 10

# Parameters for the model
mu = default_scalar_type(5/14); K = default_scalar_type(5/3)
gamma = default_scalar_type(1.0e-6)
beta_1 = default_scalar_type(0.01); beta_2 = default_scalar_type(1e-5)

# Mesh
p0 = [0.0, 0.0] 
p1 = [1.0, 0.5]
Nx, Ny = 20, 10
mesh0 = create_rectangle(MPI.COMM_WORLD, [p0, p1], [Nx, Ny], cell_type=CellType.triangle)

# Parameter d
coordinates = mesh0.geometry.x
x_coords = coordinates[:, 0]; y_coords = coordinates[:, 1]
x_range = np.max(x_coords) - np.min(x_coords)
y_range = np.max(y_coords) - np.min(y_coords)
d = max(x_range, y_range)

# Displacement
Vu = functionspace(mesh0, ("CG", mesh_order, (mesh0.geometry.dim, )))
du = TrialFunction(Vu); v = TestFunction(Vu)
u = Function(Vu, name="displacement"); u_old = Function(Vu)
u_prev = Function(Vu); u_old_prev = Function(Vu)

# Extra unknown p
Vp = functionspace(mesh0, (p_space, mesh_order))
dp = TrialFunction(Vp); q = TestFunction(Vp)
p = Function(Vp, name="p"); p_old = Function(Vp)
p_prev = Function(Vp); p_old_prev = Function(Vp)

# Mark different materials
tol = 1e-8
local_cells = mesh0.topology.index_map(mesh0.topology.dim).size_local
marker = np.zeros(local_cells, dtype=np.int32)
cells_medium1 = locate_entities(mesh0, mesh0.topology.dim, 
                               lambda x: (x[0] >= 0.1 - tol) & (x[1] >= 0.1 - tol) & 
                                         (x[1] <= 0.4 + tol))
marker[cells_medium1] = 2

potential_body1 = locate_entities(mesh0, mesh0.topology.dim, 
                             lambda x: (x[0] <= 0.1 + tol))
potential_body2 = locate_entities(mesh0, mesh0.topology.dim, 
                             lambda x: (x[1] <= 0.1 + tol) & (x[0] <= 1.0 + tol))
potential_body3 = locate_entities(mesh0, mesh0.topology.dim, 
                             lambda x: (x[1] >= 0.4 - tol) & (x[0] <= 1.0 + tol))

all_potential_body = np.concatenate([potential_body1, potential_body2, potential_body3])
# Only mark cells as body if they haven't already been marked as medium
for cell_id in all_potential_body:
    if marker[cell_id] == 0:
        marker[cell_id] = 1

material_tags = meshtags(mesh0, mesh0.topology.dim, np.arange(local_cells), marker)
dx = Measure("dx", domain=mesh0, subdomain_data=material_tags)
material_markers = material_tags.values

# Apply BCs
left = lambda x: np.isclose(x[0], 0.0)
top_right_corner = lambda x: np.isclose(x[0], 1.0) & np.isclose(x[1], 0.5)
left_facet = locate_entities_boundary(mesh0, mesh0.topology.dim - 1, left)
top_facet = locate_entities_boundary(mesh0, 0, top_right_corner)

ul = np.array((0,) * mesh0.geometry.dim, dtype=default_scalar_type)
ut = Constant(mesh0, default_scalar_type(0))
bcl = dirichletbc(ul, locate_dofs_topological(Vu, mesh0.topology.dim - 1, left_facet), Vu)
bct = dirichletbc(ut, locate_dofs_topological(Vu.sub(1), 0, top_facet), Vu.sub(1))
bcu = [bcl, bct]

# Kinematics
dim = len(u)
I = variable(Identity(dim))             # Identity tensor
F_0 = variable(I + grad(u))             # Deformation gradient
F = as_tensor([[F_0[0, 0], F_0[0, 1], 0],
               [F_0[1, 0], F_0[1, 1], 0],
               [0, 0, 1]])                  # Deformation gradient in 3D
C = variable(F.T*F)                     # Right Cauchy-Green tensor
Ic = variable(tr(C))
J  = variable(det(F))

psi = (K/2)*(ln(J))**2 + (mu/2)*(J**(-2/3)*Ic - 3)
psi_2 = (mu/2)*(J**(-2/3)*Ic - 3)

# Potential energy
# dx(1): bodies; dx(2): third medium
Pi_body = psi*dx(1)
Pi_m = gamma*psi_2 * dx(2)

Pi_tan_R = ( beta_1/2 * ((F[0,1] - F[1,0]) / (F[0,0] + F[1,1]) - 1/d * p)**2 
    + beta_2/2 * inner(grad(p), grad(p)) ) * dx(2)

Pi_medium = Pi_m + Pi_tan_R
Pi_total = Pi_body + Pi_medium

L = derivative(Pi_total, u, v)

bilin = beta_1/d**2 * inner(dp, q) * dx(2) + beta_2 * inner(grad(dp), grad(q)) * dx(2) 
lin = beta_1/d * inner(((F[0,1] - F[1,0]) / (F[0,0] + F[1,1])), q) * dx(2)

class NonlinearPDE_SNESProblem:
    def __init__(self, F, u, bcs):
        V = u.function_space
        du = TrialFunction(V)
        self.L = form(F)
        self.a = form(derivative(F, u, du))
        self.bcs = bcs
        self._F, self._J = None, None
        self.u = u

    def F(self, snes, x, F):
        x.ghostUpdate(addv=PETSc.InsertMode.INSERT, mode=PETSc.ScatterMode.FORWARD)
        x.copy(self.u.x.petsc_vec)
        self.u.x.petsc_vec.ghostUpdate(addv=PETSc.InsertMode.INSERT, mode=PETSc.ScatterMode.FORWARD)
            
        with F.localForm() as f_local:
            f_local.set(0.0)
        assemble_vector(F, self.L)
        apply_lifting(F, [self.a], bcs=[self.bcs], x0=[x], alpha=-1.0)
        F.ghostUpdate(addv=PETSc.InsertMode.ADD, mode=PETSc.ScatterMode.REVERSE)
        set_bc(F, self.bcs, x, -1.0)

    def J(self, snes, x, J, P):
        J.zeroEntries()
        assemble_matrix(J, self.a, bcs=self.bcs)
        J.assemble()

def update_p():
    A = create_matrix(form(bilin))
    b = create_vector(Vp)
    assemble_matrix(A, form(bilin))
    A.assemble()
    A.shift(3e-14)  
    
    with b.localForm() as b_local:
        b_local.set(0.0)
    assemble_vector(b, form(lin))
    b.ghostUpdate(addv=PETSc.InsertMode.ADD, mode=PETSc.ScatterMode.REVERSE)
    
    solver = PETSc.KSP().create(mesh0.comm)
    solver.setOperators(A)
    solver.setType(PETSc.KSP.Type.PREONLY)
    solver.getPC().setType(PETSc.PC.Type.LU)
    solver.setFromOptions()
    
    x = create_vector(Vp)
    solver.solve(b, x)
    x.copy(p.x.petsc_vec)
    p.x.petsc_vec.ghostUpdate(addv=PETSc.InsertMode.INSERT, mode=PETSc.ScatterMode.FORWARD)
    
    solver.destroy(); A.destroy(); b.destroy(); x.destroy()
    return 0

def compute_error(a, a_old):
    a_diff = a.x.array - a_old.x.array
    a_norm = np.linalg.norm(a.x.array)
    err_a = np.linalg.norm(a_diff)
    a_rel_diff = err_a / (a_norm + 1e-14)
    return err_a, a_rel_diff, a_norm, a_diff

def staggered_residuals():
    err_u, u_rel_diff, u_norm, u_diff = compute_error(u, u_old)
    err_p, p_rel_diff, p_norm, p_diff = compute_error(p, p_old)

    concatenate_norm = np.linalg.norm(np.concatenate((u.x.array, p.x.array), axis=0))
    err = np.linalg.norm(np.concatenate((u_diff, p_diff), axis=0))
    err_rel_diff = err / (concatenate_norm + 1e-14)
    return err, err_u, err_p, u_norm, p_norm, err_rel_diff, u_rel_diff, p_rel_diff

with XDMFFile(mesh0.comm, f"{file_name}/results_{file_name}.xdmf", "w") as xdmf_file:
    xdmf_file.write_mesh(mesh0)
    xdmf_file.write_function(u, 0)
    xdmf_file.write_function(p, 0)

    # Adaptive load stepping loop
    err_p = 0.0; p_rel_diff = 0.0
    current_displacement = 0.0; step_size = initial_step_size; n = 0
    while current_displacement > target_displacement:
        k = 0; j = 0
        success_ad = False

        while not success_ad and k < max_attempts:
            k += 1

            # New displacement step
            next_displacement = max(current_displacement - step_size, target_displacement)

            # Update Dirichlet boundary condition
            ut = Constant(mesh0, default_scalar_type(next_displacement))
            bct = dirichletbc(ut, locate_dofs_topological(Vu.sub(1), 0, top_facet), Vu.sub(1))
            bcu = [bcl, bct]

            # Save current state before attempting the step
            u_prev.x.array[:] = u.x.array[:]; u_old_prev.x.array[:] = u_old.x.array[:]
            p_prev.x.array[:] = p.x.array[:]; p_old_prev.x.array[:] = p_old.x.array[:]

            # Create SNES solver
            problem = NonlinearPDE_SNESProblem(L, u, bcu)
            b = create_vector(Vu)
            J_L = create_matrix(problem.a)
            snes = PETSc.SNES().create()
            snes.setFunction(problem.F, b)
            snes.setJacobian(problem.J, J_L)
            snes.setTolerances(max_it=max_it_newton)
            snes.getKSP().setType("preonly")
            snes.getKSP().getPC().setType("lu")

            opts = PETSc.Options()
            opts["pc_factor_mat_solver_type"] = "mumps"
            opts['snes_linesearch_type'] = linesearch
            opts['snes_max_linear_solve_fail'] = 20
            opts['snes_linesearch_max_it'] = 20
            opts['snes_monitor'] = None
            opts['snes_linesearch_monitor'] = None
            opts['snes_converged_reason'] = None
            snes.setFromOptions()

            try:
                itr = 0; c0 = False
                # Staggered iterations
                while not c0:
                    itr += 1; print("itr=: ", itr)

                    x = u.x.petsc_vec.copy()
                    x.ghostUpdate(addv=PETSc.InsertMode.INSERT, mode=PETSc.ScatterMode.FORWARD)
                    snes.solve(None, x)  # Compute u
                    if snes.getConvergedReason() > 0:
                        x.copy(u.x.petsc_vec)
                        u.x.petsc_vec.ghostUpdate(addv=PETSc.InsertMode.INSERT, mode=PETSc.ScatterMode.FORWARD)
                    else:
                        raise RuntimeError(f"Newton failed due to error:{snes.getConvergedReason()}")
                    print(f"Iterations: {snes.getIterationNumber()}, Residual: {snes.getFunctionNorm()}")
                    x.destroy()
                    x = None

                    update_p()  # Compute p

                    # Check convergence of staggered iterations
                    err, err_u, err_p, u_norm, p_norm, err_rel_diff, u_rel_diff, p_rel_diff = staggered_residuals()

                    c0 = err < err_tol_staggered
                    c1 = itr > max_it_staggered
                    if c1 and not c0:
                        raise RuntimeError(f"Staggered iterations failed, must reduce load step size")

                    if c0:
                        xdmf_file.write_function(u, n + 1)
                        xdmf_file.write_function(p, n + 1)

                    u_old.x.array[:] = u.x.array[:]; p_old.x.array[:] = p.x.array[:]

                success_ad = True
                n += 1
                current_displacement = next_displacement

                # Change increase factor when |displacement| is big
                if current_displacement <= crit_displacement:
                    increase_factor = 1.1
                step_size = min(step_size * increase_factor, max_step_size)

            except Exception as e:
                print(f"Step failed with error: {e}")
                traceback.print_exc()

                # Restore to previous state and reduce step size
                u.x.array[:] = u_prev.x.array[:]; u_old.x.array[:] = u_old_prev.x.array[:]
                p.x.array[:] = p_prev.x.array[:]; p_old.x.array[:] = p_old_prev.x.array[:]
                step_size = max(step_size * decrease_factor, min_step_size)
                print(f"Reducing step size to {step_size:.6f}")

                if step_size == min_step_size:
                    j += 1

                if j == 2:
                    print(f"Already reached the minimum step size {min_step_size} and still failing.")

            finally:
                snes.destroy()
                J_L.destroy()
                b.destroy()
                if 'x' in dir() and x is not None:
                    x.destroy()

            if j == 2:
                break

        if j == 2 or (not success_ad and k == max_attempts):
            print(f"Step {n + 1} failed after {k} attempts.")
            print(f"Final displacement achieved: {current_displacement:.6f}")
            break

    print(f"Finished. Total successful steps written: {n}, final displacement: {current_displacement:.6f}")

# ============================================================
# POST-PROCESSING
# ============================================================
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
from dolfinx import plot

topology_u, _, geometry_u = plot.vtk_mesh(Vu)
topology_p, _, geometry_p = plot.vtk_mesh(Vp)

tri_u = topology_u.reshape(-1, 4)[:, 1:]
tri_p = topology_p.reshape(-1, 4)[:, 1:]

bs = Vu.dofmap.index_map_bs

u_vals = u.x.array.reshape(-1, bs)
u_mag = np.linalg.norm(u_vals, axis=1)

x_def = geometry_u[:, 0] + u_vals[:, 0]
y_def = geometry_u[:, 1] + u_vals[:, 1]

target_width = 10.0
x_span = x_def.max() - x_def.min()
y_span = y_def.max() - y_def.min()
aspect_ratio = y_span / x_span if x_span > 0 else 1.0
fig_height = max(target_width * aspect_ratio, 2.0) 

triang_def = mtri.Triangulation(x_def, y_def, tri_u)

fig1, ax1 = plt.subplots(figsize=(target_width, fig_height))
tpc1 = ax1.tricontourf(triang_def, u_mag, levels=20, cmap="viridis")
ax1.triplot(triang_def, color="k", linewidth=0.1, alpha=0.3)
ax1.set_aspect("equal")
ax1.set_title("Deformation – |u|")
fig1.colorbar(tpc1, ax=ax1, label="|u|")
fig1.tight_layout()
fig1.savefig("displacement_deformed_cbox.png", dpi=200)

print("Saved: displacement_deformed_cbox.png")