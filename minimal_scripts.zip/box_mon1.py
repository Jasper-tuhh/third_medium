import numpy as np
import pyvista
from dolfinx.io import XDMFFile
from dolfinx.io import gmsh as gmshio
import gmsh 
from petsc4py import PETSc
from mpi4py import MPI
from ufl import *
from dolfinx.fem import *
from dolfinx.fem.petsc import *
from dolfinx.mesh import *
from dolfinx import default_scalar_type, plot, default_real_type
from dolfinx.fem.petsc import (
    create_matrix, assemble_matrix, apply_lifting, 
    assemble_vector, set_bc, LinearProblem, create_vector
)
from basix.ufl import element, mixed_element

file_name = "box_mon" 
eq3 = 2 
linesearch = 'bt'
mesh_order = 1
target_displacement = -1.0
p_space = "CG"

# Nonlinear solver parameters
atol_newton = 1e-18; rtol_newton = 1e-17; stol_newton = 1e-20; max_it_newton = 10

# Adaptive load stepping parameters
Nsteps = 12; Nsteps_min = 10; Nsteps_max = 200
crit_displacement = -0.4
initial_step_size = abs(target_displacement)/Nsteps
min_step_size = abs(target_displacement)/Nsteps_max
max_step_size = abs(target_displacement)/Nsteps_min 
increase_factor = 1.5; decrease_factor = 0.5
max_attempts = 10

# Parameters for the model
mu = default_scalar_type(10); K = default_scalar_type(20)
gamma = default_scalar_type(1.0e-6)
beta_1 = default_scalar_type(0.1); beta_2 = default_scalar_type(1e-4)

# Mesh
p0 = [0.0, 0.0] 
p1 = [2.0, 0.5]
Nx, Ny = 80, 20
mesh0 = create_rectangle(MPI.COMM_WORLD, [p0, p1], [Nx, Ny], cell_type=CellType.triangle)

# Parameter d
coordinates = mesh0.geometry.x
x_coords = coordinates[:, 0]; y_coords = coordinates[:, 1]
x_range = np.max(x_coords) - np.min(x_coords)
y_range = np.max(y_coords) - np.min(y_coords)
d = max(x_range, y_range)

# Mixed function space for unknowns
P_u = element("CG", mesh0.basix_cell(), mesh_order, shape=(mesh0.geometry.dim,), dtype=default_real_type)
P_p = element(p_space, mesh0.basix_cell(), mesh_order, dtype=default_real_type)
P_mx = mixed_element([P_u, P_p])
V = functionspace(mesh0, P_mx)
(v, q) = TestFunctions(V)

w_V = Function(V); w_V_prev = Function(V)
u, p = split(w_V)

Vu0 = V.sub(0); Vp0 = V.sub(1)
Vu, dofu = Vu0.collapse(); Vp, dofp = Vp0.collapse()

# Mark different materials
tol = 1e-8
local_cells = mesh0.topology.index_map(mesh0.topology.dim).size_local
marker = np.zeros(local_cells, dtype=np.int32)
cells_medium = locate_entities(mesh0, mesh0.topology.dim, 
                               lambda x: (x[0] >= 0.1 - tol) & (x[0] <= 1.9 + tol) & 
                                         (x[1] >= 0.1 - tol) & (x[1] <= 0.4 + tol))
marker[cells_medium] = 2

all_potential_body = locate_entities(mesh0, mesh0.topology.dim, 
                             lambda x: (x[0] <= 0.1 + tol) | (x[0] >= 1.9 - tol) | 
                                       (x[1] <= 0.1 + tol) | (x[1] >= 0.4 - tol))
# Only mark cells as body if they haven't already been marked as medium
for cell_id in all_potential_body:
    if marker[cell_id] == 0:
        marker[cell_id] = 1 

material_tags = meshtags(mesh0, mesh0.topology.dim, np.arange(local_cells), marker)
dx = Measure("dx", domain=mesh0, subdomain_data=material_tags)

# Output for ParaView
xdmf_file = XDMFFile(mesh0.comm, f"{file_name}/results_{file_name}.xdmf", "w")
xdmf_file.write_mesh(mesh0)
u_out = Function(Vu, name="u_out")
xdmf_file.write_function(u_out, 0)
p_out = Function(Vp, name="p_out")
xdmf_file.write_function(p_out, 0)

# Apply BCs
left_corner = lambda x: np.isclose(x[0], 0.0) & np.isclose(x[1], 0.0)
right_corner = lambda x: np.isclose(x[0], 2.0) & np.isclose(x[1], 0.0)
top_midpoint = lambda x: np.isclose(x[0], 1.0) & np.isclose(x[1], 0.5)
left_facet = locate_entities_boundary(mesh0, 0, left_corner)
right_facet = locate_entities_boundary(mesh0, 0, right_corner)
top_facet = locate_entities_boundary(mesh0, 0, top_midpoint)

ul = Function(Vu)
ur = Constant(mesh0, default_scalar_type(0))
ut = Constant(mesh0, default_scalar_type(0))
bcl = dirichletbc(ul, locate_dofs_topological((Vu0, Vu), 0, left_facet), Vu0)
bcr = dirichletbc(ur, locate_dofs_topological(Vu0.sub(1), 0, right_facet), Vu0.sub(1))
bct = dirichletbc(ut, locate_dofs_topological(Vu0.sub(1), 0, top_facet), Vu0.sub(1))
bcu = [bcl, bcr, bct]

# Kinematics
dim = len(u)
I = variable(Identity(dim))             # Identity tensor
F_0 = variable(I + grad(u))             # Deformation gradient
F = as_tensor([[F_0[0, 0], F_0[0, 1], 0],
               [F_0[1, 0], F_0[1, 1], 0],
               [0, 0, 1]])                  # Deformation gradient in 3D
C = variable(F.T*F)                     # Right Cauchy-Green tensor
Ic = variable(tr(C))
J  = variable(det(F))

# Strain energy density in 3D
psi = (K/2)*(ln(J))**2 + (mu/2)*(J**(-2/3)*Ic - 3)
psi_2= (mu/2)*(J**(-2/3)*Ic - 3)

# Potential energy
# dx(1): body; dx(2): third medium
Pi_body = psi*dx(1)
Pi_m = gamma*psi_2 * dx(2)

Pi_tan_R = ( beta_1/2 * ((F[0,1] - F[1,0]) / (F[0,0] + F[1,1]) - 1/d * p)**2 
    + beta_2/2 * inner(grad(p), grad(p)) ) * dx(2)

Pi_medium = Pi_m + Pi_tan_R
Pi_total = Pi_body + Pi_medium

L_u = derivative(Pi_total, u, v)

# To solve p
epsilon_penalty = 1e-16
Pi_penalty_R = epsilon_penalty * inner(p, p) * dx(1)
Pi_total_R = Pi_tan_R + Pi_penalty_R

L_p = derivative(Pi_total_R, p, q)

# Combine the two parts of the weak form
L = L_u + L_p


class NonlinearPDE_SNESProblem:
    def __init__(self, F, u, bcs):
        V = u.function_space
        du = TrialFunction(V)
        self.L = form(F)
        self.a = form(derivative(F, u, du))
        self.bcs = bcs
        self._F, self._J = None, None
        self.u = u

    def F(self, snes, x, F):
        x.ghostUpdate(addv=PETSc.InsertMode.INSERT, mode=PETSc.ScatterMode.FORWARD)
        x.copy(self.u.x.petsc_vec)
        self.u.x.petsc_vec.ghostUpdate(addv=PETSc.InsertMode.INSERT, mode=PETSc.ScatterMode.FORWARD)
            
        with F.localForm() as f_local:
            f_local.set(0.0)
        assemble_vector(F, self.L)
        apply_lifting(F, [self.a], bcs=[self.bcs], x0=[x], alpha=-1.0)
        F.ghostUpdate(addv=PETSc.InsertMode.ADD, mode=PETSc.ScatterMode.REVERSE)
        set_bc(F, self.bcs, x, -1.0)

    def J(self, snes, x, J, P):
        J.zeroEntries()
        assemble_matrix(J, self.a, bcs=self.bcs)
        J.assemble()

# Adaptive load stepping loop
current_displacement = 0.0; step_size = initial_step_size; n = 0
while current_displacement > target_displacement:
    k = 0; j = 0
    success_ad = False
    
    while not success_ad and k < max_attempts:
        k += 1

        # New displacement step
        next_displacement = max(current_displacement - step_size, target_displacement)
        
        # Update Dirichlet boundary condition
        ut = Constant(mesh0, default_scalar_type(next_displacement))
        bct = dirichletbc(ut, locate_dofs_topological(Vu0.sub(1), 0, top_facet), Vu0.sub(1))
        bcu = [bcl, bcr, bct]

        # Save current state before attempting the step
        w_V_prev.x.array[:] = w_V.x.array[:]

        # Create SNES solver
        problem = NonlinearPDE_SNESProblem(L, w_V, bcs=bcu)
        b = create_vector(V)
        J_L = create_matrix(problem.a)
        snes = PETSc.SNES().create()
        snes.setFunction(problem.F, b)
        snes.setJacobian(problem.J, J_L)
        snes.setTolerances(max_it=max_it_newton)
        snes.getKSP().setType("preonly")
        snes.getKSP().getPC().setType("lu")

        opts = PETSc.Options()
        opts["pc_factor_mat_solver_type"] = "mumps"
        opts['snes_linesearch_type'] = linesearch
        opts['snes_max_linear_solve_fail'] = 20
        opts['snes_linesearch_max_it'] = 20
        opts['snes_monitor'] = None
        opts['snes_linesearch_monitor'] = None
        opts['snes_converged_reason'] = None
        snes.setFromOptions()

        try:
            print("n=: ", n)
            x = w_V.x.petsc_vec.copy()
            x.ghostUpdate(addv=PETSc.InsertMode.INSERT, mode=PETSc.ScatterMode.FORWARD)
            snes.solve(None, x) # Compute u and p
            if snes.getConvergedReason() > 0:
                x.copy(w_V.x.petsc_vec)
                w_V.x.petsc_vec.ghostUpdate(addv=PETSc.InsertMode.INSERT, mode=PETSc.ScatterMode.FORWARD)
            else:
                raise RuntimeError(f"Newton failed due to error:{snes.getConvergedReason()}")    
            print(f"Iterations: {snes.getIterationNumber()}, Residual: {snes.getFunctionNorm()}")

            u_out.x.array[:] = w_V.sub(0).collapse().x.array[:]
            xdmf_file.write_function(u_out, n+1)
            p_out.x.array[:] = w_V.sub(1).collapse().x.array[:]
            xdmf_file.write_function(p_out, n+1)

            success_ad = True
            n += 1
            current_displacement = next_displacement

            if current_displacement <= crit_displacement:
                increase_factor = 1.1
            step_size = min(step_size * increase_factor, max_step_size)
            
        except Exception as e: 
            # Restore to previous state and reduce step size
            w_V.x.array[:] = w_V_prev.x.array[:]
            step_size = max(step_size * decrease_factor, min_step_size)
            print(f"Step failed with error: {e}")
            print(f"Reducing step size to {step_size:.6f}")

            if step_size == min_step_size:
                j += 1

            if j == 2:
                print(f"Already reached the minimum step size {min_step_size} and still failing.")
                break

    if j == 2 or (not success_ad and k >= max_attempts):
        print(f"Step {n+1} failed after {k} attempts.")
        print(f"Final displacement achieved: {current_displacement:.6f}")
        break


# ============================================================
# POST-PROCESSING
# ============================================================
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
from dolfinx import plot

topology_u, _, geometry_u = plot.vtk_mesh(Vu)
topology_p, _, geometry_p = plot.vtk_mesh(Vp)

tri_u = topology_u.reshape(-1, 4)[:, 1:]
tri_p = topology_p.reshape(-1, 4)[:, 1:]

bs = Vu.dofmap.index_map_bs
u_vals = u_out.x.array.reshape(-1, bs)
u_mag = np.linalg.norm(u_vals, axis=1)

x_def = geometry_u[:, 0] + u_vals[:, 0]
y_def = geometry_u[:, 1] + u_vals[:, 1]

target_width = 10.0
x_span = x_def.max() - x_def.min()
y_span = y_def.max() - y_def.min()
aspect_ratio = y_span / x_span if x_span > 0 else 1.0
fig_height = max(target_width * aspect_ratio, 2.0)  

triang_def = mtri.Triangulation(x_def, y_def, tri_u)

fig1, ax1 = plt.subplots(figsize=(target_width, fig_height))
tpc1 = ax1.tricontourf(triang_def, u_mag, levels=20, cmap="viridis")
ax1.triplot(triang_def, color="k", linewidth=0.1, alpha=0.3)
ax1.set_aspect("equal")
ax1.set_title("Deformation – |u|")
fig1.colorbar(tpc1, ax=ax1, label="|u|")
fig1.tight_layout()
fig1.savefig("displacement_deformed_box_mon.png", dpi=200)

print("Saved: displacement_deformed_box_mon.png")
plt.show()